import React, { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer, Legend, BarChart, Bar, Area, AreaChart } from "recharts";
import { Calculator, PiggyBank, Landmark, ChartLine, Target, RefreshCw, Download, Info } from "lucide-react";

// ==========================
// Utilidades financieras
// ==========================
const toNumber = (v) => {
  if (typeof v === "number") return v;
  if (!v) return 0;
  const cleaned = String(v).replace(/[^0-9.,-]/g, "").replace(/\.(?=.*\.)/g, "");
  const normalized = cleaned.replace(/\./g, "").replace(",", ".");
  const n = parseFloat(normalized);
  return isNaN(n) ? 0 : n;
};

const fmtCOP = (n) =>
  new Intl.NumberFormat("es-CO", { style: "currency", currency: "COP", maximumFractionDigits: 0 }).format(n || 0);

const fmtPct = (n) => `${(n * 100).toFixed(2)}%`;

// Convierte tasa nominal anual a efectiva mensual
const nomToEffMonthly = (annualNominal, periodsPerYear = 12) => {
  const i = annualNominal / periodsPerYear;
  return i;
};

// Convierte tasa efectiva anual a efectiva mensual
const effAnnualToMonthly = (ea) => Math.pow(1 + ea, 1 / 12) - 1;

// Convierte tasa nominal vencida m.v. a efectiva anual
const mvmToEA = (mvm) => Math.pow(1 + mvm, 12) - 1;

// FV con aporte periódico al final de cada periodo (annuity, ordinary)
const fvAnnuity = (rate, n, pmt, pv = 0) => {
  // rate: por periodo (p.e. mensual)
  const r = rate;
  if (r === 0) return pv + pmt * n;
  return pv * Math.pow(1 + r, n) + pmt * ((Math.pow(1 + r, n) - 1) / r);
};

// NPV (VAN) con flujos y tasa efectiva por periodo
const npv = (rate, cashflows) => cashflows.reduce((acc, cf, t) => acc + cf / Math.pow(1 + rate, t), 0);

// IRR (TIR) por búsqueda binaria
const irr = (cashflows, guessLow = -0.99, guessHigh = 10, tol = 1e-7, maxIter = 200) => {
  let low = guessLow, high = guessHigh;
  for (let i = 0; i < maxIter; i++) {
    const mid = (low + high) / 2;
    const v = npv(mid, cashflows);
    const vLow = npv(low, cashflows);
    if (Math.abs(v) < tol) return mid;
    if (v * vLow < 0) high = mid; else low = mid;
  }
  return (low + high) / 2;
};

// Resuelve aporte mensual requerido para meta (por método de Newton)
const requiredMonthlyContribution = (rateMonthly, nMonths, objetivo, inicial) => {
  const r = rateMonthly;
  if (r === 0) return Math.max((objetivo - inicial) / nMonths, 0);
  const factor = Math.pow(1 + r, nMonths);
  const numerador = objetivo - inicial * factor;
  const denom = (factor - 1) / r;
  return Math.max(numerador / denom, 0);
};

// Genera datos de serie para gráficas
const serieMeses = (n) => Array.from({ length: n + 1 }, (_, i) => i);

// ==========================
// Componentes UI base (Tailwind)
// ==========================
const Section = ({ title, icon, children, right }) => (
  <div className="bg-white rounded-2xl shadow-sm p-5 border border-slate-200">
    <div className="flex items-center justify-between mb-4">
      <div className="flex items-center gap-3">
        {icon}
        <h2 className="text-xl font-semibold text-slate-800">{title}</h2>
      </div>
      {right}
    </div>
    {children}
  </div>
);

const Field = ({ label, suffix, children }) => (
  <label className="block">
    <div className="text-sm text-slate-600 mb-1">{label}</div>
    <div className="flex items-stretch rounded-xl border border-slate-300 overflow-hidden focus-within:ring-2 focus-within:ring-slate-400">
      {children}
      {suffix && (
        <div className="px-3 py-2 bg-slate-50 text-slate-600 text-sm flex items-center">{suffix}</div>
      )}
    </div>
  </label>
);

const Input = (props) => (
  <input
    {...props}
    className={`px-3 py-2 outline-none w-full ${props.className || ""}`}
  />
);

const Select = (props) => (
  <select {...props} className={`px-3 py-2 outline-none w-full ${props.className || ""}`} />
);

const Button = ({ children, className = "", ...rest }) => (
  <button
    {...rest}
    className={`px-4 py-2 rounded-xl shadow-sm bg-slate-900 text-white hover:bg-slate-800 active:scale-[.99] transition ${className}`}
  >
    {children}
  </button>
);

const GhostButton = ({ children, className = "", ...rest }) => (
  <button
    {...rest}
    className={`px-4 py-2 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 transition ${className}`}
  >
    {children}
  </button>
);

const Help = ({ text }) => (
  <div className="flex items-center gap-2 text-slate-500 text-sm">
    <Info size={16} /> {text}
  </div>
);

// ==========================
// Simulador CDT
// ==========================
function SimuladorCDT() {
  const [monto, setMonto] = useState(10000000);
  const [plazoMeses, setPlazoMeses] = useState(12);
  const [tasaEA, setTasaEA] = useState(0.12); // 12% EA
  const [retencion, setRetencion] = useState(0.04); // 4% retención en la fuente aprox.
  const [capitalizacion, setCapitalizacion] = useState("mensual"); // mensual o al vencimiento

  const tasaMensual = useMemo(() => effAnnualToMonthly(toNumber(tasaEA)), [tasaEA]);

  // cálculo de valor futuro neto
  const { serie, bruto, interes, retencionVal, neto } = useMemo(() => {
    const n = toNumber(plazoMeses);
    const m = toNumber(monto);
    const r = tasaMensual;

    let value = m;
    const data = [{ mes: 0, valor: value }];

    if (capitalizacion === "mensual") {
      for (let i = 1; i <= n; i++) {
        value = value * (1 + r);
        data.push({ mes: i, valor: value });
      }
    } else {
      // al vencimiento (interés simple sobre el período)
      const valueEnd = m * (1 + Math.pow(1 + r, n) - 1);
      for (let i = 1; i <= n; i++) {
        const prog = m + (valueEnd - m) * (i / n);
        data.push({ mes: i, valor: prog });
      }
      value = valueEnd;
    }

    const brutoVF = value;
    const interesG = brutoVF - m;
    const rete = interesG * toNumber(retencion);
    const netoVF = brutoVF - rete;

    return { serie: data, bruto: brutoVF, interes: interesG, retencionVal: rete, neto: netoVF };
  }, [monto, plazoMeses, tasaMensual, retencion, capitalizacion]);

  const reset = () => {
    setMonto(10000000); setPlazoMeses(12); setTasaEA(0.12); setRetencion(0.04); setCapitalizacion("mensual");
  };

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <Section
        title="Parámetros del CDT"
        icon={<Landmark className="text-slate-700" />}
        right={<GhostButton onClick={reset}><RefreshCw size={16} className="inline mr-2"/>Reiniciar</GhostButton>}
      >
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Monto a invertir" suffix="COP">
            <Input type="number" value={monto} onChange={(e) => setMonto(toNumber(e.target.value))} />
          </Field>
          <Field label="Plazo" suffix="meses">
            <Input type="number" value={plazoMeses} onChange={(e) => setPlazoMeses(toNumber(e.target.value))} />
          </Field>
          <Field label="Tasa efectiva anual (EA)" suffix="%">
            <Input type="number" step="0.01" value={(tasaEA * 100).toString()} onChange={(e) => setTasaEA(toNumber(e.target.value) / 100)} />
          </Field>
          <Field label="Retención sobre intereses" suffix="%">
            <Input type="number" step="0.01" value={(retencion * 100).toString()} onChange={(e) => setRetencion(toNumber(e.target.value) / 100)} />
          </Field>
          <Field label="Capitalización">
            <Select value={capitalizacion} onChange={(e) => setCapitalizacion(e.target.value)}>
              <option value="mensual">Mensual (compuesto)</option>
              <option value="vencimiento">Al vencimiento (simple)</option>
            </Select>
          </Field>
        </div>
        <div className="mt-4">
          <Help text="Nota: Cálculo ilustrativo. Tasas reales, impuestos y comisiones pueden variar según entidad." />
        </div>
      </Section>

      <Section title="Resultados" icon={<ChartLine className="text-slate-700" />}>
        <div className="grid grid-cols-2 gap-4">
          <Stat label="Valor futuro bruto" value={fmtCOP(bruto)} />
          <Stat label="Intereses generados" value={fmtCOP(interes)} />
          <Stat label="Retención estimada" value={fmtCOP(retencionVal)} />
          <Stat label="Valor futuro neto" value={fmtCOP(neto)} highlight />
        </div>
        <div className="h-64 mt-6">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={serie} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
              <defs>
                <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0f172a" stopOpacity={0.2}/>
                  <stop offset="95%" stopColor="#0f172a" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="mes" tickFormatter={(v) => `${v}`}/>
              <YAxis tickFormatter={(v) => `${Math.round(v/1_000_000)}M`} />
              <Tooltip formatter={(v) => fmtCOP(v)} labelFormatter={(l) => `Mes ${l}`} />
              <Area type="monotone" dataKey="valor" stroke="#0f172a" fill="url(#g1)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </Section>
    </div>
  );
}

const Stat = ({ label, value, highlight }) => (
  <div className={`rounded-xl p-4 border ${highlight ? "border-slate-900 bg-slate-900 text-white" : "border-slate-200 bg-slate-50"}`}>
    <div className={`text-sm ${highlight ? "text-slate-200" : "text-slate-600"}`}>{label}</div>
    <div className={`text-xl font-semibold mt-1 ${highlight ? "text-white" : "text-slate-800"}`}>{value}</div>
  </div>
);

// ==========================
// Simulador Fondos / ETFs (aportes periódicos)
// ==========================
function SimuladorFondosETFs({ tipo = "Fondos" }) {
  const [inicial, setInicial] = useState(2000000);
  const [aporte, setAporte] = useState(500000);
  const [tasaEA, setTasaEA] = useState(0.10);
  const [meses, setMeses] = useState(36);
  const [comision, setComision] = useState(0.0); // sobre aporte

  const r = effAnnualToMonthly(toNumber(tasaEA));

  const { serie, valorFinal, totalAportes, totalComisiones, intereses } = useMemo(() => {
    const n = toNumber(meses);
    const ap = toNumber(aporte);
    const ini = toNumber(inicial);
    const fee = toNumber(comision);

    let saldo = ini;
    const data = [{ mes: 0, saldo }];
    let aportado = ini;
    let fees = 0;

    for (let i = 1; i <= n; i++) {
      const feeVal = ap * fee;
      fees += feeVal;
      saldo = saldo * (1 + r) + ap - feeVal; // interés + aporte - comisión
      aportado += ap;
      data.push({ mes: i, saldo });
    }

    const valorFinal = saldo;
    const intereses = valorFinal - (aportado - ini) - ini - fees + ini; // simplifica a valorFinal - aportes - fees + intereses sobre ini

    return { serie: data, valorFinal, totalAportes: aportado - ini, totalComisiones: fees, intereses };
  }, [inicial, aporte, meses, comision, r]);

  const reset = () => { setInicial(2000000); setAporte(500000); setTasaEA(0.10); setMeses(36); setComision(0); };

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <Section title={`Parámetros – ${tipo}`} icon={<PiggyBank className="text-slate-700" />} right={<GhostButton onClick={reset}><RefreshCw size={16} className="inline mr-2"/>Reiniciar</GhostButton>}>
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Aporte inicial" suffix="COP">
            <Input type="number" value={inicial} onChange={(e) => setInicial(toNumber(e.target.value))} />
          </Field>
          <Field label="Aporte mensual" suffix="COP">
            <Input type="number" value={aporte} onChange={(e) => setAporte(toNumber(e.target.value))} />
          </Field>
          <Field label="Horizonte" suffix="meses">
            <Input type="number" value={meses} onChange={(e) => setMeses(toNumber(e.target.value))} />
          </Field>
          <Field label="Rentabilidad esperada (EA)" suffix="%">
            <Input type="number" step="0.01" value={(tasaEA * 100).toString()} onChange={(e) => setTasaEA(toNumber(e.target.value) / 100)} />
          </Field>
          <Field label="Comisión sobre aporte" suffix="%">
            <Input type="number" step="0.01" value={(comision * 100).toString()} onChange={(e) => setComision(toNumber(e.target.value) / 100)} />
          </Field>
        </div>
        <div className="mt-4">
          <Help text="Este simulador proyecta con tasa constante mensual equivalente. No considera volatilidad del mercado." />
        </div>
      </Section>

      <Section title="Resultados" icon={<ChartLine className="text-slate-700" />}>
        <div className="grid grid-cols-2 gap-4">
          <Stat label="Valor final" value={fmtCOP(valorFinal)} highlight />
          <Stat label="Total aportes" value={fmtCOP(totalAportes)} />
          <Stat label="Comisiones" value={fmtCOP(totalComisiones)} />
          <Stat label="Intereses / rendimientos" value={fmtCOP(valorFinal - totalAportes - inicial - totalComisiones)} />
        </div>
        <div className="h-64 mt-6">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={serie} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="mes" />
              <YAxis tickFormatter={(v) => `${Math.round(v/1_000_000)}M`} />
              <Tooltip formatter={(v) => fmtCOP(v)} labelFormatter={(l) => `Mes ${l}`} />
              <Legend />
              <Line type="monotone" dataKey="saldo" stroke="#0f172a" dot={false} name="Saldo" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Section>
    </div>
  );
}

// ==========================
// Meta / Ahorro Objetivo
// ==========================
function SimuladorMeta() {
  const [objetivo, setObjetivo] = useState(100000000);
  const [inicial, setInicial] = useState(5000000);
  const [meses, setMeses] = useState(48);
  const [tasaEA, setTasaEA] = useState(0.10);

  const r = effAnnualToMonthly(tasaEA);
  const aporteRequerido = useMemo(
    () => requiredMonthlyContribution(r, toNumber(meses), toNumber(objetivo), toNumber(inicial)),
    [r, meses, objetivo, inicial]
  );

  // Serie para mostrar progreso si se cumple el aporte requerido
  const serie = useMemo(() => {
    let saldo = toNumber(inicial);
    const n = toNumber(meses);
    const data = [{ mes: 0, saldo }];
    for (let i = 1; i <= n; i++) {
      saldo = saldo * (1 + r) + aporteRequerido;
      data.push({ mes: i, saldo, objetivo: toNumber(objetivo) });
    }
    return data;
  }, [inicial, meses, r, aporteRequerido, objetivo]);

  const reset = () => { setObjetivo(100000000); setInicial(5000000); setMeses(48); setTasaEA(0.10); };

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <Section title="Parámetros – Meta de ahorro" icon={<Target className="text-slate-700" />} right={<GhostButton onClick={reset}><RefreshCw size={16} className="inline mr-2"/>Reiniciar</GhostButton>}>
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Meta objetivo" suffix="COP">
            <Input type="number" value={objetivo} onChange={(e) => setObjetivo(toNumber(e.target.value))} />
          </Field>
          <Field label="Aporte inicial" suffix="COP">
            <Input type="number" value={inicial} onChange={(e) => setInicial(toNumber(e.target.value))} />
          </Field>
          <Field label="Horizonte" suffix="meses">
            <Input type="number" value={meses} onChange={(e) => setMeses(toNumber(e.target.value))} />
          </Field>
          <Field label="Rentabilidad esperada (EA)" suffix="%">
            <Input type="number" step="0.01" value={(tasaEA * 100).toString()} onChange={(e) => setTasaEA(toNumber(e.target.value) / 100)} />
          </Field>
        </div>
        <div className="mt-4">
          <Help text="Calcula el aporte mensual necesario para alcanzar una meta en el tiempo definido." />
        </div>
      </Section>

      <Section title="Resultado" icon={<ChartLine className="text-slate-700" />}>
        <div className="grid grid-cols-2 gap-4">
          <Stat label="Aporte mensual requerido" value={fmtCOP(aporteRequerido)} highlight />
          <Stat label="Horizonte" value={`${meses} meses`} />
        </div>
        <div className="h-64 mt-6">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={serie} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="mes" />
              <YAxis tickFormatter={(v) => `${Math.round(v/1_000_000)}M`} />
              <Tooltip formatter={(v, n) => n === 'objetivo' ? fmtCOP(v) : fmtCOP(v)} labelFormatter={(l) => `Mes ${l}`} />
              <Legend />
              <Line type="monotone" dataKey="saldo" stroke="#0f172a" dot={false} name="Saldo estimado" />
              <Line type="monotone" dataKey="objetivo" stroke="#64748b" dot={false} name="Objetivo" strokeDasharray="4 4" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Section>
    </div>
  );
}

// ==========================
// Proyección de FCL (Flujo de Caja Libre) + VAN/TIR
// ==========================
function SimuladorFCL() {
  const [anioInicial, setAnioInicial] = useState(2025);
  const [periodos, setPeriodos] = useState(10);
  const [fclBase, setFclBase] = useState(20000000);
  const [crecimiento, setCrecimiento] = useState(0.08);
  const [wacc, setWacc] = useState(0.14);
  const [inversionInicial, setInversionInicial] = useState(50000000);

  const flujos = useMemo(() => {
    const n = toNumber(periodos);
    let f = [];
    let valor = toNumber(fclBase);
    for (let i = 1; i <= n; i++) {
      if (i === 1) valor = toNumber(fclBase); else valor = valor * (1 + toNumber(crecimiento));
      f.push(valor);
    }
    return f;
  }, [periodos, fclBase, crecimiento]);

  const van = useMemo(() => {
    const tasa = toNumber(wacc);
    const cfs = [ -toNumber(inversionInicial), ...flujos ];
    return npv(tasa, cfs);
  }, [wacc, inversionInicial, flujos]);

  const tir = useMemo(() => irr([ -toNumber(inversionInicial), ...flujos ]), [inversionInicial, flujos]);

  const serie = useMemo(() => flujos.map((v, i) => ({ anio: toNumber(anioInicial) + i, fcl: v })), [flujos, anioInicial]);

  const reset = () => { setAnioInicial(2025); setPeriodos(10); setFclBase(20000000); setCrecimiento(0.08); setWacc(0.14); setInversionInicial(50000000); };

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <Section title="Parámetros – FCL" icon={<Calculator className="text-slate-700" />} right={<GhostButton onClick={reset}><RefreshCw size={16} className="inline mr-2"/>Reiniciar</GhostButton>}>
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Año inicial">
            <Input type="number" value={anioInicial} onChange={(e) => setAnioInicial(toNumber(e.target.value))} />
          </Field>
          <Field label="Número de períodos">
            <Input type="number" value={periodos} onChange={(e) => setPeriodos(toNumber(e.target.value))} />
          </Field>
          <Field label="FCL base (año 1)" suffix="COP">
            <Input type="number" value={fclBase} onChange={(e) => setFclBase(toNumber(e.target.value))} />
          </Field>
          <Field label="Crecimiento anual" suffix="%">
            <Input type="number" step="0.01" value={(crecimiento * 100).toString()} onChange={(e) => setCrecimiento(toNumber(e.target.value) / 100)} />
          </Field>
          <Field label="WACC / tasa descuento" suffix="%">
            <Input type="number" step="0.01" value={(wacc * 100).toString()} onChange={(e) => setWacc(toNumber(e.target.value) / 100)} />
          </Field>
          <Field label="Inversión inicial" suffix="COP">
            <Input type="number" value={inversionInicial} onChange={(e) => setInversionInicial(toNumber(e.target.value))} />
          </Field>
        </div>
        <div className="mt-4">
          <Help text="Calcula VAN y TIR con flujos crecientes. No incluye valor terminal ni capital de trabajo." />
        </div>
      </Section>

      <Section title="Resultados" icon={<ChartLine className="text-slate-700" />}>
        <div className="grid grid-cols-3 gap-4">
          <Stat label="VAN" value={fmtCOP(van)} highlight={van > 0} />
          <Stat label="TIR" value={fmtPct(tir)} highlight={tir > toNumber(wacc)} />
          <Stat label="Criterio" value={van > 0 ? "Proyecto viable" : "Proyecto no viable"} />
        </div>
        <div className="h-64 mt-6">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={serie} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="anio" />
              <YAxis tickFormatter={(v) => `${Math.round(v/1_000_000)}M`} />
              <Tooltip formatter={(v) => fmtCOP(v)} />
              <Bar dataKey="fcl" fill="#0f172a" name="FCL" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Section>
    </div>
  );
}

// ==========================
// Export CSV helper
// ==========================
const downloadCSV = (rows, filename = "simulacion.csv") => {
  const csv = rows.map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
};

// ==========================
// App principal
// ==========================
const TABS = [
  { key: "cdt", label: "CDT", icon: <Landmark size={16} /> },
  { key: "fondos", label: "Fondos", icon: <PiggyBank size={16} /> },
  { key: "etfs", label: "ETFs", icon: <PiggyBank size={16} /> },
  { key: "meta", label: "Meta", icon: <Target size={16} /> },
  { key: "fcl", label: "FCL", icon: <Calculator size={16} /> },
];

export default function App() {
  const [tab, setTab] = useState("cdt");

  return (
    <div className="min-h-screen bg-slate-100">
      <header className="sticky top-0 z-10 backdrop-blur bg-white/80 border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <ChartLine className="text-slate-900" />
              <h1 className="text-2xl font-bold text-slate-900">Simuladores de Planeación Financiera</h1>
            </div>
            <div className="hidden md:flex items-center gap-2">
              {TABS.map(t => (
                <button key={t.key} onClick={() => setTab(t.key)} className={`px-3 py-2 rounded-xl text-sm border ${tab === t.key ? "bg-slate-900 text-white border-slate-900" : "bg-white hover:bg-slate-50 border-slate-300"}`}>
                  <div className="flex items-center gap-2">{t.icon}<span>{t.label}</span></div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6">
        <div className="md:hidden mb-4">
          <Select value={tab} onChange={(e) => setTab(e.target.value)}>
            {TABS.map(t => (<option key={t.key} value={t.key}>{t.label}</option>))}
          </Select>
        </div>

        <AnimatePresence mode="wait">
          {tab === "cdt" && (
            <motion.div key="cdt" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }}>
              <SimuladorCDT />
            </motion.div>
          )}
          {tab === "fondos" && (
            <motion.div key="fondos" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }}>
              <SimuladorFondosETFs tipo="Fondos" />
            </motion.div>
          )}
          {tab === "etfs" && (
            <motion.div key="etfs" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }}>
              <SimuladorFondosETFs tipo="ETFs" />
            </motion.div>
          )}
          {tab === "meta" && (
            <motion.div key="meta" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }}>
              <SimuladorMeta />
            </motion.div>
          )}
          {tab === "fcl" && (
            <motion.div key="fcl" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }}>
              <SimuladorFCL />
            </motion.div>
          )}
        </AnimatePresence>

        <div className="mt-8 grid md:grid-cols-2 gap-6">
          <Section title="Notas importantes" icon={<Info className="text-slate-700" />}>
            <ul className="list-disc pl-6 space-y-2 text-slate-600">
              <li>Valores ilustrativos en COP. Usa tasas efectivas anuales (EA) y se convierten a tasa mensual equivalente.</li>
              <li>Los cálculos no sustituyen asesoría financiera profesional. Verifica comisiones, impuestos y términos reales de cada entidad.</li>
              <li>Puedes exportar cualquier tabla de resultados ajustando el código para añadir filas y usar el botón de descarga (incluye ejemplo helper).</li>
            </ul>
          </Section>

          <Section title="Exportar resultados (ejemplo)" icon={<Download className="text-slate-700" />} right={<GhostButton onClick={() => {
            const rows = [["Campo","Valor"],["Ejemplo","Descarga CSV"]];
            downloadCSV(rows, "ejemplo.csv");
          }}>Descargar CSV</GhostButton>}>
            <p className="text-slate-600">Este botón descarga un CSV de ejemplo. Integra tu propia data preparando un arreglo de filas.</p>
          </Section>
        </div>
      </main>

      <footer className="max-w-6xl mx-auto px-4 py-10 text-center text-slate-500">
        Prototipo educativo inspirado en simuladores Skandia. Construido con React, Tailwind, Recharts y Framer Motion.
      </footer>
    </div>
  );
}
